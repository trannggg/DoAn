package com.web.dto.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ThongKe {

    private Long soCuDan;

    private Long soCanHo;

    private Long soCanHoTrong;

    private Long soPhuongTien;
}
