package com.web.repository;

import com.web.entity.VehicleServiceFee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleServiceFeeRepository extends JpaRepository<VehicleServiceFee, Long> {
}
